packages <- c( 'sf', 'tmap', 'shiny', 'shinythemes', 
              'plotly', 'tidyverse', 'ggstatsplot', 
              'tools')

for (p in packages){
  library(p, character.only = TRUE)
}


























ui <- fluidPage(
    titlePanel("Dashboard"),
    sidebarLayout(
      sidebarPanel(
        selectInput(inputId = "inputDistrict",
                    label = "District :",
                    choices = sort(wp_ngaTrim$shapeName),
                    selected = "Aba North")),
    mainPanel(
      tmapOutput(outputId = "tmapMap")
        )))

server <- function(input, output) {
  dataTmap <- reactive({
    sf::st_as_sf(
      wp_ngaTrim %>%
        filter(shapeName %>% input$inputDistrict))})
  
  output$tmapMap <- renderTmap({
    tm_shape(boundary) +
      tm_polygons() +
    tm_shape(dataTmap) +
      tm_fill(input$dataTmap) +
      tm_borders(alpha = 0.5)})}

shinyApp(ui = ui, server = server)
